package ejemploinstanceof;

public class Rectangulo extends FiguraGeometrica{

     public void dibujar(){
        System.out.println("dibujar rectangulo");
    }
}
