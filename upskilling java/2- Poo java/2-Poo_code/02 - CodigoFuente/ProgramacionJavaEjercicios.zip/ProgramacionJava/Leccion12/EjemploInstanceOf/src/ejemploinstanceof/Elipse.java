package ejemploinstanceof;

public class Elipse extends Circulo {

    public void dibujar() {
        System.out.println("dibujar elipse");
    }
}
