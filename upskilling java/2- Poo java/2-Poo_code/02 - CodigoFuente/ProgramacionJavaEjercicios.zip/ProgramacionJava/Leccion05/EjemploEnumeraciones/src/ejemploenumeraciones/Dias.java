package ejemploenumeraciones;

public enum Dias {

    //Son valores constantes, por eso van en mayusculas
    LUNES,
    MARTES,
    MIERCOLES,
    JUEVES,
    VIERNES,
    SABADO,
    DOMINGO
}
