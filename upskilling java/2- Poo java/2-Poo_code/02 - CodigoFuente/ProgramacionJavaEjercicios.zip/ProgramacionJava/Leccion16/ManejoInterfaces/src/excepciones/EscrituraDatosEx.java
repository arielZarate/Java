package excepciones;

public class EscrituraDatosEx extends AccesoDatosEx{

    public EscrituraDatosEx(String mensaje) {
        super(mensaje);
    }
    
}
