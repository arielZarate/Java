package excepciones;

public class ExcepcionLecturaDatos extends AccesoDatosEx{

    public ExcepcionLecturaDatos(String mensaje) {
        super(mensaje);
    }
    
}
