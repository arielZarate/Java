package estructuraclase;

public class EstructuraClase {

    public static void main(String[] args) {

    }
    
}
