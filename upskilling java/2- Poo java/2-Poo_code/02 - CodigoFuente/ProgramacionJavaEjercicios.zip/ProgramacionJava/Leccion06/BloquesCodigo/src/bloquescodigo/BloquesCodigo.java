package bloquescodigo;

public class BloquesCodigo {

    public static void main(String[] args) {

        Persona p1 = new Persona();
        int id = p1.getIdPersona();
        System.out.println("id Persona:" + id);
    }
    
}
