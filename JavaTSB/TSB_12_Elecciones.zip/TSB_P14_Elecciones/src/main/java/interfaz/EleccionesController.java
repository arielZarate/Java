package interfaz;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.DirectoryChooser;
import negocio.Agrupaciones;
import negocio.Regiones;

import java.io.File;
import java.util.Collection;

public class EleccionesController {
    public ListView lvwResultados;
    public Label lblUbicacion;
    public ComboBox cboDistritos;

    public void onExaminarClick(ActionEvent actionEvent) {
        DirectoryChooser chooser = new DirectoryChooser();
        File file = chooser.showDialog(null);
        if (file != null)
            lblUbicacion.setText(file.getPath());
    }

    public void onCargarClick(ActionEvent actionEvent) {
        Agrupaciones agrupaciones = new Agrupaciones();
        //Cargar en el list view la cantidad de votos total por agrupacion politica
        Collection resultado = agrupaciones.generarEscrutinio(lblUbicacion.getText() + "\\descripcion_postulaciones.dsv", lblUbicacion.getText() + "\\mesas_totales_agrp_politica.dsv");
        ObservableList ol;
        ol = FXCollections.observableArrayList(resultado);
        lvwResultados.setItems(ol);
        //Cargar en una lista desplegable los distritos (provincias)
        Regiones regiones = new Regiones(lblUbicacion.getText() + "\\descripcion_regiones.dsv");
        Collection distritos = regiones.getDistritos();
        ol = FXCollections.observableArrayList(distritos);
        cboDistritos.setItems(ol);
    }
}