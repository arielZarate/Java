package soporte;

import negocio.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TSBTextFile {
    private File file;

    public TSBTextFile(String path) {
        file = new File(path);
    }

    public String leerEncabezado() {
        String linea = "";
        try {
            Scanner scanner = new Scanner(file);
            if (scanner.hasNext())
                linea = scanner.nextLine();
        } catch (FileNotFoundException e) {
            System.out.println("No se encontró el archivo " + file);
        }
        return linea;
    }

    public TSBHashtable identificarAgrupaciones()
    {
        String campos[];
        TSBHashtable table = new TSBHashtable(10);
        try {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNext()) {
                campos = scanner.nextLine().split("\\|");
                if(campos[0].compareTo("000100000000000")==0) {
                    Agrupacion agrupacion = new Agrupacion(campos[2], campos[3]);
                    table.put(agrupacion.getCodigo(), agrupacion);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("No se encontró el archivo " + file);
        }
        return table;
    }

    public void sumarVotosPorAgrupacion(TSBHashtable table) {
        String campos[];
        try {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNext()) {
                campos = scanner.nextLine().split("\\|");
                if(campos[4].compareTo("000100000000000")==0) {
                    Agrupacion agrupacion = (Agrupacion) table.get(campos[5]);
                    agrupacion.sumarVotos(Integer.parseInt(campos[6]));
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("No se encontró el archivo " + file);
        }
    }

    public Region identificarRegiones()
    {
        String campos[];
        Region pais = new Region("00","Argentina");
        Region distrito;
        try {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNext()) {
                campos = scanner.nextLine().split("\\|");
                switch(campos[0].length())
                {
                    case 2:
                        distrito = new Region(campos[0], campos[1]);
                        pais.agregarSubregion(distrito);
                        break;
                    case 5:
                        Region seccion = new Region(campos[0], campos[1]);
                        distrito = (Region) pais.getOrPutSubregion(campos[0].substring(0,2));
                        distrito.agregarSubregion(seccion);
                        break;
                    case 11:

                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("No se encontró el archivo " + file);
        }
        return pais;
    }
}
