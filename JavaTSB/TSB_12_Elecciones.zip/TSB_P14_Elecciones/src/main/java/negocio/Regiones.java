package negocio;


import soporte.TSBTextFile;

import java.util.Collection;

public class Regiones {
    private Region pais;

    public Regiones(String path) {
        TSBTextFile file = new TSBTextFile(path);
        pais = file.identificarRegiones();
    }

    public Collection getDistritos() {
        return pais.getSubregiones().values();
    }
}
