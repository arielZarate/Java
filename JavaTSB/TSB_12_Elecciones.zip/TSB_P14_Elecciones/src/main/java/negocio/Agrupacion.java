package negocio;

public class Agrupacion {
    private String codigo;
    private String nombre;
    private int votos;

    public Agrupacion(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.votos = 0;
    }

    public String getCodigo() {
        return codigo;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("\n");
        sb.append(codigo).append("| ");
        sb.append(nombre).append(" | ");
        sb.append(votos).append(" votos");
        return sb.toString();
    }

    public void sumarVotos(int cantidad)
    {
        votos += cantidad;
    }
}
