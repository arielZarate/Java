package negocio;

import soporte.TSBHashtable;

public class Region {
    private String codigo;
    private String nombre;
    private TSBHashtable subregiones;

    public Region(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
        subregiones = new TSBHashtable();
    }

    public void agregarSubregion(Region region) {
        subregiones.put(region.codigo, region);
    }

    public TSBHashtable getSubregiones() {
        return subregiones;
    }

    @Override
    public String toString() {
        return "(" + codigo + ") " + nombre;
    }

    public Object getOrPutSubregion(String codigo) {
        Region region = (Region) subregiones.get(codigo);
        if (region != null)
            return region;
        else {
            subregiones.put(codigo, new Region(codigo, ""));
            return subregiones.get(codigo);
        }
    }

}
