package negocio;

import soporte.TSBHashtable;
import soporte.TSBTextFile;

import java.util.Collection;

public class Agrupaciones {
    private TSBHashtable agrupaciones;

    public Agrupaciones() {
        agrupaciones = new TSBHashtable(10);
    }

    public Collection generarEscrutinio(String rutaPostulaciones, String rutaMesas){
        //Recorrer el archivo de postulaciones identificando que agrupaciones presentan candidato a presidente
        TSBTextFile filePostulaciones = new TSBTextFile(rutaPostulaciones);
        agrupaciones = filePostulaciones.identificarAgrupaciones();
        //Acumular para cada agrupacion cuantos votos recibió en cada una de las mesas procesadas para candidato a presidente
        TSBTextFile fileMesas = new TSBTextFile(rutaMesas);
        fileMesas.sumarVotosPorAgrupacion(agrupaciones);
        return agrupaciones.values();
    }
}
